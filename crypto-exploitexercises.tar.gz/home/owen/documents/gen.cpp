#include <iostream>
#include <stdlib.h>

using namespace std;

int main() {
    int x[20];

    x[11] = 0;
    x[18] = 2;
    x[19] = 1;
    x[8] = 5;

    x[9] = 12 - x[8];
    x[1] = 2 / x[18];
    x[15] = x[1] + 5;
    x[17] = x[15]+1;
    x[5] = x[17] -1;
    x[0] = x[17] - 4;
    x[4] =  10 - x[15];
    x[10] = x[15] + 2;
    x[12] = x[19] + 1;
    x[6] = x[4] - 1;
    x[7] = x[1] + 4;
    x[13] = 14 - x[8];

    for (int i = 0; i<2; i++) {
        if (i == 0) { 
            x[16] = 8;
        } else {
           x[16] = 5;
        }
        x[2] = x[16];
        x[14] = 40 / x[16];
        for (int j=0; j<10; j++) {
            x[3] = j;
            for (int k=0; k<20; k++) {
                cout << x[k];
            }
            cout << endl;
        }
    }
}
