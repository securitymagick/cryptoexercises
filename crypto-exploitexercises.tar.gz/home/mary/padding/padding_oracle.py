#!/usr/bin/env python
import sys
from Crypto.Cipher import AES


def pkcs(msg):
  padding_length = ord(msg[-1])
  padding = msg[-padding_length:]
  if (padding != (chr(padding_length)*padding_length)):
    return None
  return msg[:-padding_length]

def decrypt(cipher,enc):
  dec = ""
  if ((len(enc) % 16) != 0):
    return (False)
  dec = cipher.decrypt(enc)
  msg = pkcs(dec)
  if msg is None:
    return (False)
  return (True)



#actual key and iv go here...
key = "498AB10D2332EC1700DF56218879BC43".decode("hex")
iv  = "F598532CCD776001A44BF310694C4921".decode("hex")

if len(sys.argv) != 2:
  print "Usage: %s CIPHERTEXT"%(sys.argv[0])
  sys.exit()

cipherhex = sys.argv[1]
ciphertext = cipherhex.decode("hex")

cipher = AES.new(key, AES.MODE_CBC, iv)
success = decrypt(cipher,ciphertext) 
if (success):
    print "TRUE. \n"
else:
    print "FALSE. \n"	


