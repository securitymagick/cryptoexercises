#!/usr/bin/env python
import sys
import random

upperCase = "ABCDEFGHIJKLMNOPQRSTUVQXYZ"
lowerCase = "abcdefghijklnmopqrstuvqxyz"
num    = "9876543210"
keychars = upperCase + num + lowerCase

if len(sys.argv) != 2:
  print "Usage: %s PLAINTEXT"%(sys.argv[0])
  sys.exit()

plaintext = sys.argv[1]

key = lowerCase[random.randint(0,25)] + upperCase[random.randint(0,25)]
key = key + num[random.randint(0,9)] + lowerCase[random.randint(0,25)]
key = key + upperCase[random.randint(0,25)]

cipher = ""
for i in range(len(plaintext)):
  rotate_amount = keychars.index(key[i%len(key)])
  if plaintext[i] in lowerCase:
    newChar = ord('a') + (ord(plaintext[i])-ord('a') - 3 - rotate_amount)%26
  elif plaintext[i] in num:
    newChar = ord('0') + (ord(plaintext[i])-ord('0')- 1 - rotate_amount)%10
  elif plaintext[i] in upperCase:
    newChar = ord('A') + (ord(plaintext[i])-ord('A') - 2 - rotate_amount)%26
  else:
    newChar = ord(plaintext[i])
  cipher = cipher + chr(newChar)

print "CIPHER IS: (%s)"%(cipher)
